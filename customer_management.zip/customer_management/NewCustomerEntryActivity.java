package com.bignerdranch.android.customer_management;

import android.graphics.Picture;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.UUID;
import java.util.jar.Attributes;

import com.bignerdranch.android.customer_management.Customer_List_Database_Package.Customer_List_Database_Helper;
import com.bignerdranch.android.customer_management.Customer_List_Database_Package.Customer_List_Database.CustomerListTable;
import com.bignerdranch.android.customer_management.Customer_List_Database_Package.Customer_List_Database;

import static android.R.attr.id;


public class NewCustomerEntryActivity extends AppCompatActivity {

    private static NewCustomerEntryActivity sNewCustomerEntryActivity;

    private Context mContext;
    private SQLiteDatabase mDatabase;


    private NewCustomerEntryActivity(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new Customer_List_Database_Helper(mContext)
                .getWritableDatabase();


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_customer_entry);
    }

public CustomerList getCustomerList(UUID id) {
        return null;
    }




}

















